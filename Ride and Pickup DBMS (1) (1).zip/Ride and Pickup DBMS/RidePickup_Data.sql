-- 1) Address (parent for Customer, Driver, Merchant)
INSERT INTO Address (Address_ID, Country, Province, City, Street_Address, Postal_Code)
VALUES (1, 'Canada', 'Ontario', 'Toronto', '123 King St', 'M5G1X5');

-- 2) Locations (pickup/dropoff)
INSERT INTO Location (Location_ID, Street_Address, City, Province, Postal_Code, Country, GPS_Coordinates)
VALUES (1, '456 Queen St', 'Toronto', 'Ontario', 'M5H2N2', 'Canada', NULL);
INSERT INTO Location (Location_ID, Street_Address, City, Province, Postal_Code, Country, GPS_Coordinates)
VALUES (2, '789 Bay St', 'Toronto', 'Ontario', 'M5B2C5', 'Canada', NULL);

-- 3) Customer (needs Address_ID=1)
INSERT INTO Customer (Customer_ID, First_Name, Last_Name, Phone_Number, Email_Address,
                      Date_Of_Birth, Signup_Date, Balance, Address_ID)
VALUES (1, 'John', 'Doe', '4161234567', 'john.doe@email.com',
        TO_DATE('1990-05-20','YYYY-MM-DD'), SYSDATE, 50.00, 1);

-- 4) Driver (needs Address_ID=1)
INSERT INTO Driver (Driver_ID, First_Name, Last_Name, Phone_Number, Date_Of_Birth,
                    License_Info, Insurance_Info, Address_ID)
VALUES (1, 'Jane', 'Smith', '4169876543', TO_DATE('1985-10-10','YYYY-MM-DD'),
        'LIC12345', 'InsureCo #123', 1);

-- 5) Vehicle (needs Driver_ID=1)
INSERT INTO Vehicle (Vehicle_ID, License_Plate, Make, Model, Colour, Year, Vehicle_Type, Driver_ID)
VALUES (1, 'ABC123', 'Toyota', 'Camry', 'Black', 2020, 'Sedan', 1);

-- 6) Merchant (needs Address_ID=1)
INSERT INTO Merchant (Merchant_ID, Name, Address_ID)
VALUES (1, 'Pizza Place', 1);

-- 7) Service order (needs Customer_ID=1, Driver_ID=1, Merchant_ID=1, and two Location_IDs)
INSERT INTO Service_Order (Order_ID, Customer_ID, Driver_ID, Merchant_ID, Status,
                           Order_Time, Fare, Pickup_Location_ID, Dropoff_Location_ID)
VALUES (1, 1, 1, 1, 'Pending', CURRENT_TIMESTAMP, 25.50, 1, 2);

-- 8) Payment (child of Service_Order)
INSERT INTO Payment (Payment_ID, Order_ID, Payment_Type, Amount, Status)
VALUES (1, 1, 'Credit', 25.50, 'Paid');

-- 9) Rating (child of Service_Order, Customer, Driver)
INSERT INTO Rating_System (Rating_ID, Order_ID, Customer_ID, Driver_ID, Customer_Stars,
                           Customer_Feedback, Driver_Stars, Driver_Feedback)
VALUES (1, 1, 1, 1, 5, 'Great driver!', 5, 'Polite customer');

-- Commit the test data
COMMIT;

-- Quick checks
SELECT * FROM Address;
SELECT * FROM Location;
SELECT * FROM Customer;
SELECT * FROM Driver;
SELECT * FROM Vehicle;
SELECT * FROM Merchant;
SELECT * FROM Service_Order;
SELECT * FROM Payment;
SELECT * FROM Rating_System;
